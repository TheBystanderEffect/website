# Testovacie scenáre pre layer

## Vytvorenie layeru

1. Z bočného menu klikneme na tlačítko **Add layer**
2. Klikneme na prázdne miesto v canvase
3. Na canvase sa vytvorý prázdny layer

## Vymazanie layeru

1. Z bočného menu klikneme na tlačítko **Delete layer**
2. Klikneme na layer
3. Layer je vymazaný aj so všetkými lifelinami a messagami ktoré sa v ňom nachádzali