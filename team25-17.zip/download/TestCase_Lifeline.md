# Testovacie scenáre pre lifeline

## Vytvorenie lifelinu

1. Z bočného menu klikneme na tlačítko **Add lifeline**
2. Klikneme na miesto v layeri
3. Na danom mieste sa vytvorí lifeline
4. Ak sú v blízkosti iné lifeliny, tak sa posunu aby vytvorili miesto pre nový lifeline
5. Ak nie je miesto na layeri tak sa layer rostiahne aby vytvoril miesto


## Vymazanie lifelinu

1. Z bočného menu klikneme na tlačítko **Delete lifeline**
2. Klikneme na lifeline ktorý chceme vymazať
3. Všetk messagi ktoré boli napojené na daný lifeline sa vymažú
3. Lifeliny sa posunú aby vyplnili priestor po vymazanom lifeline

## Interakcia s lifelinom

### Premenovanie lifelinu

1. Dvojklikneme na názov lifelinu
2. Zobrazí sa pop-up okno v ktorom napíšeme nový názov lifelinu
3. Po stlačení tlačítka *Enter*, sa lifeline premenuje

### Posunutie lifelinu

1. Klikneme a podržíme tlačítko na lifeline
2. Dokážeme lifeline posúvať iba v horizontálnom smere
3. Po presunutí lifelinu sa vymenia ostatné lifeliny, a aktualizujú sa polohy a smery messeagov